package Bar;

import java.util.Scanner;

public class BarManager {

	public void signUp(Scanner scan) {
		
		
	}

	public void logIn(Scanner scan) {
		// TODO Auto-generated method stub
		
	}

	public void addMoney(Scanner scan) {
		// TODO Auto-generated method stub
		
	}

	public void myPage(Scanner scan) {
		// TODO Auto-generated method stub
		
	}

	public void reservation(Scanner scan) {
		// TODO Auto-generated method stub
		
	}

	public void delRes(Scanner scan) {
		// TODO Auto-generated method stub
		
	}

	public void printMenu() {
		// TODO Auto-generated method stub
		
	}

	public void orderPick(Scanner scan) {
		// TODO Auto-generated method stub
		
	}

	public void printReceipt() {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
