package ddddddddd;

public class cmain {

	public static void main(String[] args) {
	CardPack2 cp = new CardPack2();
	cp.shuffle();
	
	
	int cnt =0;
	for(int i=0; i <4; i++) {
		for(int j =0; j < 13; j++) {
			cp.getPack()[cnt].print();
			cnt++;
		}
		System.out.println();
	}
	
	card2 play1 =cp.pick();
	card2 play2 =cp.pick();
	
	play1.print();
	play2.print();
	}
}
