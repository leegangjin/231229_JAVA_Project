
package day_01;

public class Helloworld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 주석 : 프로그램이 읽지 않는 라인 cltl+ /
		// 한줄 주석
		/* 여러줄 주석
		 * 
		 * println() : 줄바꿈이 있는 출력
		 * print() : 줄바꿈이 없는 출력
		 * printf() : 형식을 가지는 출력 (c언어에서 주로 사용)
		 **/
	System.out.println("Hello world~~!!!");
	
	int num = 100;
	int num1;
	num1 = 200;
	
	int num2 , num3 , num4;
	System.out.println(num);
	
	num = 1000;
	System.out.println(num);
	
	num3 = 500;
	System.out.println(num3);
	
}

}
