package day17;

public @interface override {

}
